/* Orbit 360 · Owner canónico del directorio operativo de Aseguradoras · 2026-07-22
   Usuario visible. Contraseña con revelado temporal. Cuenta visible y copia directa. */
(function () {
  'use strict';
  window.Orbit = window.Orbit || {};
  var Orbit = window.Orbit;
  var VERSION = '20260829.1';
  var COMPOSITION_REVISION = '20260909.1-server-owned-credential-copy';
  if (Orbit.clientInsurerOperationalDirectoryOwnerV20260722 && Orbit.clientInsurerOperationalDirectoryOwnerV20260722.version === VERSION) return;

  function clean(value) { return String(value == null ? '' : value).trim(); }
  function esc(value) {
    if (Orbit.ui && Orbit.ui.esc) return Orbit.ui.esc(clean(value));
    return clean(value).replace(/[&<>"']/g, function (c) { return ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[c]; });
  }
  function safeUrl(value) {
    var raw = clean(value);
    if (!raw) return '';
    return /^https?:\/\//i.test(raw) ? raw : 'https://' + raw;
  }
  function currentInsurer() {
    try {
      var id = Orbit.route && Orbit.route.params && Orbit.route.params.ficha;
      return id && Orbit.store && Orbit.store.get ? Orbit.store.get('aseguradoras', id) : null;
    } catch (error) { return null; }
  }
  function portalUser(portal) {
    return clean(portal && (portal.usuario || portal.user || portal.login || portal.emailUsuario || portal.correoUsuario));
  }
  function bankNumber(account) {
    return clean(account && (account.numero || account.numeroCuenta || account.accountNumber));
  }
  function holder(account, insurer) {
    return clean(account && account.titular) || clean(insurer && insurer.nombre) || 'Sin registrar';
  }
  function providerStatus(ref) {
    try {
      return Orbit.secureResources && Orbit.secureResources.credentialStatus
        ? Orbit.secureResources.credentialStatus(ref, { module: 'aseguradoras' })
        : { available: false };
    } catch (error) { return { available: false }; }
  }
  function activeRole() {
    try { return clean(Orbit.session && Orbit.session.rol && Orbit.session.rol()); }
    catch (error) { return ''; }
  }
  function roleKey(value) {
    return clean(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z]/g, '');
  }
  function activeAdvisor() {
    try {
      var advisorId = Orbit.session && Orbit.session.asesorId && Orbit.session.asesorId();
      return advisorId && Orbit.store && Orbit.store.get ? (Orbit.store.get('asesores', advisorId) || {}) : {};
    } catch (error) { return {}; }
  }
  function credentialAccessAllowed() {
    var advisor = activeAdvisor();
    var restricted = [].concat(advisor.restricciones || [], advisor.restrictions || []);
    if (restricted.indexOf('aseguradoras_plataformas_credenciales') >= 0 || restricted.indexOf('aseguradoras_editar') >= 0) return false;
    var extras = [].concat(advisor.permisosExtra || [], advisor.permissionsExtra || []);
    if (extras.indexOf('aseguradoras_plataformas_credenciales') >= 0 || extras.indexOf('aseguradoras_editar') >= 0) return true;
    try {
      if (Orbit.access && Orbit.access.can && (Orbit.access.can('aseguradoras', 'credentials') === true || Orbit.access.can('aseguradoras', 'edit') === true)) return true;
    } catch (error) {}
    return ['direccion','admin','superadmin','superadministrador','admintenant','operativo'].indexOf(roleKey(activeRole())) >= 0;
  }
  function inlineCredential(portal) {
    if (!credentialAccessAllowed()) return '';
    return clean(portal && (portal.password || portal.pass || portal.contrasena || portal.clave));
  }
  function credentialState(portal) {
    if (!credentialAccessAllowed()) return { allowed:false, available:false, revealAvailable:false, copyAvailable:false };
    if (inlineCredential(portal)) return { allowed:true, available:true, revealAvailable:true, copyAvailable:true, source:'record' };
    var ref = clean(portal && portal.credentialRef);
    var state = providerStatus(ref);
    return {
      allowed:true,
      available:!!(ref && state.available),
      revealAvailable:!!(ref && (state.revealAvailable || state.available)),
      copyAvailable:!!(ref && (state.copyAvailable || state.available)),
      source:'provider'
    };
  }
  async function resolveCredential(portal, insurer, index) {
    if (!credentialAccessAllowed()) return { ok:false, message:'Acceso restringido para el rol activo.' };
    var inline = inlineCredential(portal);
    if (inline) return { ok:true, value:inline, expiresInMs:6000, source:'record' };
    var ref = clean(portal && portal.credentialRef);
    if (!ref || !Orbit.secureResources || typeof Orbit.secureResources.revealCredential !== 'function') {
      return { ok:false, message:'Contraseña no disponible.' };
    }
    return await Orbit.secureResources.revealCredential(ref, { module:'aseguradoras', insurerId:insurer.id, portalIndex:index });
  }
  async function resolveCredentialForCopy(portal, insurer, index) {
    if (!credentialAccessAllowed()) return { ok:false, message:'Acceso restringido para el rol activo.' };
    var inline = inlineCredential(portal);
    if (inline) return { ok:true, value:inline, source:'record' };
    var ref = clean(portal && portal.credentialRef);
    var state = credentialState(portal);
    if (!ref || state.copyAvailable !== true || !Orbit.secureResources || typeof Orbit.secureResources.copyCredential !== 'function') {
      return { ok:false, message:'Contraseña no disponible para copia segura.' };
    }
    return await Orbit.secureResources.copyCredential(ref, { module:'aseguradoras', insurerId:insurer.id, portalIndex:index });
  }
  async function copyText(value) {
    try {
      if (Orbit.vault && Orbit.vault.copyText) return await Orbit.vault.copyText(value);
      if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(value); return true; }
    } catch (error) {}
    return false;
  }
  function toast(value) {
    try { if (Orbit.ui && Orbit.ui.toast) Orbit.ui.toast(value); } catch (error) {}
  }
  function fingerprint(value) {
    try { return JSON.stringify(value); } catch (error) { return String(Date.now()); }
  }
  function renderPortalRow(row, insurer, index) {
    var portal = insurer && insurer.portales && insurer.portales[index] || {};
    var user = portalUser(portal);
    var ref = clean(portal.credentialRef);
    var state = credentialState(portal);
    var fp = fingerprint([portal.nombre, portal.tipo, portal.url, portal.urlHint, portal.pais, portal.estadoAcceso, portal.responsable, portal.ultimaVerificacion, user, ref, state.allowed, state.available, state.revealAvailable, state.copyAvailable, state.source]);
    if (row.dataset.odOwnerVersion === VERSION && row.dataset.odFingerprint === fp) return;
    var name = clean(portal.nombre) || 'Plataforma sin nombre';
    var type = clean(portal.tipo);
    var country = clean(portal.pais || insurer.pais);
    var url = clean(portal.url || portal.urlHint);
    var status = clean(portal.estadoAcceso) || 'Sin verificar';
    var owner = clean(portal.responsable) || 'Por confirmar';
    var verified = clean(portal.ultimaVerificacion) || 'Sin verificar';
    var canReveal = !!(state.allowed && (state.revealAvailable || state.available));
    var canCopy = !!(state.allowed && (state.copyAvailable || state.available));
    row.dataset.m1PortalCard = '1';
    row.dataset.odOwnerVersion = VERSION;
    row.dataset.odFingerprint = fp;
    row.className = 'm1-portal-card od-operational-portal-card';
    row.innerHTML = '<div class="m1-portal-head"><div><strong>' + esc(name) + '</strong><span>' + esc([type,country].filter(Boolean).join(' · ') || 'Clasificación pendiente') + '</span></div><span class="badge ' + (/disponible/i.test(status) ? 'ok' : /actualiz/i.test(status) ? 'danger' : 'warn') + '">' + esc(status) + '</span></div>' +
      '<div class="m1-portal-url"><span>URL</span>' + (url ? '<a class="m1-action-link" href="' + esc(safeUrl(url)) + '" target="_blank" rel="noopener">' + esc(url) + '</a>' : '<span class="m1-empty">Sin registrar</span>') + '</div>' +
      '<div class="m1-portal-meta"><div><span>Responsable</span><b>' + esc(owner) + '</b></div><div><span>Última verificación</span><b>' + esc(verified) + '</b></div></div>' +
      '<div class="m1-credential-box od-credential-box"><div class="m1-credential-row"><span class="m1-read-label">Usuario</span><div class="m1-credential-value m1-credential-user" data-od-credential-user>' + esc(user || 'Sin usuario registrado') + '</div></div>' +
      '<div class="m1-credential-row"><span class="m1-read-label">Contraseña</span><div class="m1-credential-value m1-credential-secret" data-od-credential-secret aria-live="polite">Oculta</div></div>' +
      '<div class="m1-contact-actions">' +
        (canReveal ? '<button class="btn ghost sm" type="button" data-od-credential-reveal="' + index + '">Ver temporalmente</button>' : '<button class="btn ghost sm" type="button" disabled>' + (state.allowed ? 'Contraseña no disponible' : 'Acceso restringido') + '</button>') +
        (canCopy ? '<button class="btn ghost sm" type="button" data-od-credential-copy="' + index + '">Copiar acceso seguro</button>' : '') +
      '</div></div>' +
      (url ? '<div class="m1-contact-actions"><a class="btn primary sm" href="' + esc(safeUrl(url)) + '" target="_blank" rel="noopener">Abrir plataforma</a></div>' : '');
  }
  function renderBankRow(row, insurer, index) {
    var account = insurer && insurer.cuentas && insurer.cuentas[index] || {};
    var number = bankNumber(account);
    var fp = fingerprint([account.banco, account.tipo, number, account.moneda, account.titular, insurer && insurer.nombre]);
    if (row.dataset.odOwnerVersion === VERSION && row.dataset.odFingerprint === fp) return;
    row.dataset.m1BankCard = '1';
    row.dataset.odOwnerVersion = VERSION;
    row.dataset.odFingerprint = fp;
    row.className = 'asg-row m1-bank-card od-operational-bank-card';
    row.innerHTML = '<div class="m1-bank-labels">' +
      '<span>Banco</span><b>' + esc(clean(account.banco) || 'Sin registrar') + '</b>' +
      '<span>Tipo</span><b>' + esc(clean(account.tipo) || 'Sin registrar') + '</b>' +
      '<span>Cuenta</span><div class="m1-bank-number-line"><b data-od-bank-number>' + esc(number || 'Pendiente de registrar') + '</b></div>' +
      '<span>Moneda</span><b>' + esc(clean(account.moneda) || 'Sin registrar') + '</b>' +
      '<span>Titular</span><b>' + esc(holder(account, insurer)) + '</b>' +
      '<span>Acciones</span><div><button class="btn ghost sm" type="button" data-od-bank-copy-all="' + index + '"' + (number ? '' : ' disabled') + '>Copiar datos completos</button></div>' +
      '</div>';
  }
  function render() {
    var root = document.getElementById('asg-ficha');
    var insurer = currentInsurer();
    if (!root || !insurer) return false;
    if (root.querySelector('#af-guardar') || root.classList.contains('od-edit-mode-ready')) return true;
    root.querySelectorAll('#af-portales [data-portal]').forEach(function (row) { renderPortalRow(row, insurer, Number(row.dataset.portal)); });
    root.querySelectorAll('#af-cuentas [data-cta]').forEach(function (row) { renderBankRow(row, insurer, Number(row.dataset.cta)); });
    var portalsNote = root.querySelector('#af-portales') && root.querySelector('#af-portales').parentElement.querySelector('.cfg-note');
    if (portalsNote) portalsNote.innerHTML = '<b>Directorio operativo:</b> el usuario permanece visible. La contraseña se revela temporalmente según rol y vuelve a Oculta.';
    var accountsSection = root.querySelector('#af-cuentas') && root.querySelector('#af-cuentas').parentElement;
    var accountsNote = accountsSection && accountsSection.querySelector('.cfg-note');
    if (accountsNote) accountsNote.innerHTML = '<b>Directorio operativo:</b> el número de cuenta permanece visible y se copia directamente con banco, tipo, moneda y titular.';
    return true;
  }
  async function onClick(event) {
    var reveal = event.target.closest('[data-od-credential-reveal]');
    var credentialCopy = event.target.closest('[data-od-credential-copy]');
    if (reveal || credentialCopy) {
      event.preventDefault(); event.stopPropagation();
      var insurer = currentInsurer();
      var index = Number((reveal || credentialCopy).dataset[reveal ? 'odCredentialReveal' : 'odCredentialCopy']);
      var portal = insurer && insurer.portales && insurer.portales[index];
      var user = portalUser(portal);
      var out = reveal
        ? await resolveCredential(portal, insurer, index)
        : await resolveCredentialForCopy(portal, insurer, index);
      if (!out || out.ok === false || !clean(out.value)) { toast(out && out.message || 'Contraseña no disponible.'); return; }
      if (reveal) {
        var secret = reveal.closest('.od-credential-box') && reveal.closest('.od-credential-box').querySelector('[data-od-credential-secret]');
        if (secret) {
          secret.textContent = out.value;
          setTimeout(function () { secret.textContent = 'Oculta'; }, out.expiresInMs || 6000);
        }
        toast('Contraseña visible temporalmente');
      } else {
        var copied = await copyText(['Usuario: ' + (user || '—'), 'Contraseña: ' + out.value].join('\n'));
        toast(copied ? 'Acceso copiado de forma segura' : 'No fue posible copiar el acceso');
      }
      return;
    }
    var bank = event.target.closest('[data-od-bank-copy-all]');
    if (bank) {
      event.preventDefault(); event.stopPropagation();
      var current = currentInsurer();
      var account = current && current.cuentas && current.cuentas[Number(bank.dataset.odBankCopyAll)];
      var number = bankNumber(account);
      if (!current || !account || !number) { toast('Número de cuenta pendiente de registrar'); return; }
      var text = ['Banco: ' + (clean(account.banco) || '—'), 'Tipo: ' + (clean(account.tipo) || '—'), 'Cuenta: ' + number, 'Moneda: ' + (clean(account.moneda) || '—'), 'Titular: ' + holder(account, current)].join('\n');
      var ok = await copyText(text);
      toast(ok ? 'Datos bancarios completos copiados' : 'No fue posible copiar');
    }
  }

  var scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () { scheduled = false; render(); });
  }
  document.addEventListener('click', onClick, true);
  window.addEventListener('hashchange', schedule);
  window.addEventListener('orbit:store:emit', schedule);
  window.addEventListener('orbit:operational-directory-fields-updated', schedule);
  document.addEventListener('orbit:session', schedule);
  if (window.MutationObserver) {
    var host = document.getElementById('host');
    if (host) new MutationObserver(schedule).observe(host, { childList:true, subtree:true });
  }
  Orbit.clientInsurerOperationalDirectoryOwnerV20260722 = {
    version: VERSION,
    compositionRevision: COMPOSITION_REVISION,
    ownerId: 'clientInsurerOperationalDirectoryOwner',
    supersedesBankAndPortalSectionsOf: 'client-insurer-visual-contract-v20260720',
    usernameOperationalVisible: true,
    passwordProtectedTemporaryReveal: true,
    credentialRecordFallbackForAuthorizedRoles: true,
    credentialProviderFallbackPreserved: true,
    bankNumberOperationalVisible: true,
    bankRevealDependency: false,
    bankCopyDirect: true,
    bankCopyFields: ['banco','tipo','numero','moneda','titular'],
    bankCopyExcludesUse: true,
    bankHolderFallbackInsurer: true,
    skipsEditMode: true,
    writesStore: false,
    reimportsData: false,
    render: render
  };
  schedule();
})();
