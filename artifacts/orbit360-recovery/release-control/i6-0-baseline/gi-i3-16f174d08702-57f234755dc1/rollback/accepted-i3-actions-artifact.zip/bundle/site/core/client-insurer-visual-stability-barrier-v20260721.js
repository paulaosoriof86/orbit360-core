/* Orbit 360 · Barrera de estabilidad visual Cliente/Aseguradoras.
   Owner de carga: core/router-tenant-config-bootstrap.js.
   Distingue lectura y edición; nunca deja la ficha oculta indefinidamente. */
(function () {
  'use strict';
  window.Orbit = window.Orbit || {};
  var registryContract = { version: '20260722.1' };
  var CRITICAL_RELEASE = 'block1-critical-runtime-20260722-7';
  var DIRECTORY_VISIBILITY_REVISION = '20260902.1-latest-operational-owner-precedence';
  var previous = window.Orbit.__clientInsurerVisualStabilityBarrierV20260721;
  if (previous && previous.version === '20260722.5' && previous.directoryVisibilityRevision === DIRECTORY_VISIBILITY_REVISION) return;

  var root = document.documentElement;
  var pendingClass = 'orbit-insurer-knowledge-pending';
  var scheduled = false;
  var settling = false;
  var passId = 0;
  var maxPasses = 30;
  var style = document.querySelector('style[data-orbit-insurer-visual-stability-style]');
  if (!style) {
    style = document.createElement('style');
    style.setAttribute('data-orbit-insurer-visual-stability-style', '1');
    document.head.appendChild(style);
  }
  style.textContent = 'html.' + pendingClass + ' #asg-ficha,html.' + pendingClass + ' #host .asg-grid{visibility:hidden!important;pointer-events:none!important}';

  function routeActive() { return String(window.location && window.location.hash || '').indexOf('#/aseguradoras') === 0; }
  function ficha() { return document.getElementById('asg-ficha'); }
  function directory() { return document.querySelector('#host .asg-grid'); }
  function activeTab(view) { var tab = view && view.querySelector('.asg-tab.on[data-tab],.asg-tab.active[data-tab]'); return tab && String(tab.getAttribute('data-tab') || '').trim() || ''; }
  function count(view, selector) { return view ? view.querySelectorAll(selector).length : 0; }
  function editMode(view) { return Boolean(view && view.querySelector('#af-guardar')); }
  function editModeReady(view) {
    if (!editMode(view)) return false;
    var body = view.querySelector('#af-body');
    if (!body) return false;
    var tab = activeTab(view);
    if (tab === 'actividad') return true;
    return Boolean(body.querySelector('input,select,textarea,button') || body.textContent.trim());
  }

  function directoryReady(grid) {
    if (!grid) return false;
    return true;
  }

  function expectedReady(view) {
    if (!routeActive()) return true;
    if (!view) return directoryReady(directory());
    if (!view.classList.contains('m1-asg-ficha')) return false;
    if (editMode(view)) return editModeReady(view);
    var tab = activeTab(view);
    if (tab === 'contactos') { var contactRows = count(view, '#af-contactos .asg-row[data-cont]'); return contactRows === 0 || count(view, '.m1-contact-card') >= contactRows; }
    if (tab === 'plataformas') { var portalRows = count(view, '#af-portales [data-portal]'); return portalRows === 0 || (count(view, '.od-operational-portal-card[data-portal]') >= portalRows && count(view, '.od-credential-box') >= portalRows); }
    if (tab === 'bancos') { var bankRows = count(view, '#af-cuentas [data-cta]'); return bankRows === 0 || count(view, '.od-operational-bank-card[data-cta]') >= bankRows; }
    if (tab === 'tarifas') return Boolean(view.querySelector('#af-body .m1-knowledge-summary'));
    return true;
  }

  function publish(status, reason, ready, passes) {
    window.Orbit.__clientInsurerVisualStabilityState = {
      version: '20260722.5',
      registryVersion: registryContract.version,
      criticalRelease: CRITICAL_RELEASE,
      directoryVisibilityRevision: DIRECTORY_VISIBILITY_REVISION,
      status: status,
      reason: reason || '',
      activeTab: activeTab(ficha()),
      editMode: editMode(ficha()),
      editModeReady: editModeReady(ficha()),
      directoryReady: directoryReady(directory()),
      expectedReady: ready === true,
      passes: passes || 0,
      knowledgeSettledBeforeVisible: ready === true,
      directoryFirstPaintGuard: true,
      canonicalOwnerReapplied: ready === true,
      failVisible: true,
      eventDriven: true,
      domMutationGuard: true,
      directoryStructuralTrigger: true,
      writesStore: false
    };
  }
  function markPending(reason) { if (!routeActive()) return; root.classList.add(pendingClass); publish('waiting-stable-dom', reason, false, 0); }
  function enhanceCanonicalOwners() {
    try {
      var editOwner = window.Orbit && window.Orbit.clientInsurerEditOwnerV20260722;
      if (editOwner && typeof editOwner.enhance === 'function') editOwner.enhance();
      var readOwner = window.Orbit && window.Orbit.clientInsurerVisualContractV20260720;
      var operationalOwner = window.Orbit && window.Orbit.clientInsurerOperationalDirectoryOwnerV20260722;
      if (!editMode(ficha()) && operationalOwner && typeof operationalOwner.render === 'function') operationalOwner.render();
      if (!editMode(ficha()) && readOwner && typeof readOwner.enhance === 'function') readOwner.enhance();
      if (!editMode(ficha()) && operationalOwner && typeof operationalOwner.render === 'function') operationalOwner.render();
    } catch (error) {}
  }
  function releaseStableView(reason, passes, status) {
    root.classList.remove(pendingClass);
    publish(status || (editMode(ficha()) ? 'EDIT_MODE_READY' : 'stable'), reason, true, passes);
    try {
      document.dispatchEvent(new CustomEvent('orbit:aseguradoras:visual-stable', {
        detail: {
          version: '20260722.5',
          registryVersion: registryContract.version,
          criticalRelease: CRITICAL_RELEASE,
          directoryVisibilityRevision: DIRECTORY_VISIBILITY_REVISION,
          status: status || (editMode(ficha()) ? 'EDIT_MODE_READY' : 'stable'),
          reason: reason || '',
          passes: passes || 0
        }
      }));
    } catch (error) {}
  }

  function runStablePass(reason) {
    var currentPassId = ++passId, passes = 0; settling = true; markPending(reason);
    function pass() {
      if (currentPassId !== passId) return;
      if (!routeActive()) { settling = false; root.classList.remove(pendingClass); publish('inactive-route', reason, true, passes); return; }
      passes += 1;
      enhanceCanonicalOwners();
      requestAnimationFrame(function () {
        if (currentPassId !== passId) return;
        enhanceCanonicalOwners();
        requestAnimationFrame(function () {
          if (currentPassId !== passId) return;
          var ready = expectedReady(ficha());
          if (ready) { settling = false; releaseStableView(reason, passes); return; }
          if (passes >= maxPasses) {
            settling = false;
            releaseStableView(reason + ':max-passes', passes, 'degraded-visible');
            return;
          }
          setTimeout(pass, 40);
        });
      });
    }
    pass();
  }

  function scheduleStablePass(reason) {
    if (!routeActive()) { root.classList.remove(pendingClass); return; }
    markPending(reason);
    enhanceCanonicalOwners();
    if (expectedReady(ficha())) { releaseStableView(reason || 'synchronous-ready', 0); return; }
    if (scheduled) return;
    scheduled = true;
    setTimeout(function () { scheduled = false; runStablePass(reason || 'scheduled'); }, 0);
  }

  function touchesAseguradoras(records) {
    return Array.prototype.some.call(records || [], function (record) {
      var target = record.target;
      if (target && target.nodeType === 1 && (target.id === 'asg-ficha' || target.classList && target.classList.contains('asg-grid') || target.closest && target.closest('#asg-ficha,.asg-grid'))) return true;
      return Array.prototype.some.call(record.addedNodes || [], function (node) {
        return node && node.nodeType === 1 && (node.id === 'asg-ficha' || node.classList && node.classList.contains('asg-grid') || node.matches && node.matches('.asg-card[data-asg]') || node.querySelector && node.querySelector('#asg-ficha,.asg-grid,.asg-card[data-asg]'));
      });
    });
  }

  if (window.MutationObserver) new MutationObserver(function (records) {
    if (!routeActive() || !touchesAseguradoras(records)) return;
    if (!settling && !expectedReady(ficha())) scheduleStablePass(ficha() ? 'ficha-dom-replaced' : 'directory-dom-replaced');
  }).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('click', function (event) {
    var edit = event.target && event.target.closest && event.target.closest('#af-editar,#af-cancelar,#af-guardar,#asg-ficha [data-tab]');
    if (!edit) return;
    scheduleStablePass('interaction:' + (edit.id || edit.getAttribute('data-tab') || 'unknown'));
  }, true);
  window.addEventListener('hashchange', function () { scheduleStablePass('hashchange'); });
  window.addEventListener('orbit:aseguradoras:knowledge-loading', function () { scheduleStablePass('knowledge-loading'); });
  window.addEventListener('orbit:aseguradoras:knowledge-ready', function () { scheduleStablePass('knowledge-ready'); });
  window.addEventListener('orbit:aseguradoras:knowledge-error', function () { scheduleStablePass('knowledge-error'); });
  window.addEventListener('orbit:aseguradoras:tenant-runtime-linked', function () { scheduleStablePass('tenant-runtime-linked'); });
  window.addEventListener('orbit:aseguradoras:runtime-controlled', function () { scheduleStablePass('runtime-controlled'); });
  window.addEventListener('orbit:store:emit', function () { if (routeActive() && !expectedReady(ficha())) scheduleStablePass('store-emit'); });
  document.addEventListener('orbit:store', function () { if (routeActive() && !expectedReady(ficha())) scheduleStablePass('store-event'); });

  window.Orbit.__clientInsurerVisualStabilityBarrierV20260721 = {
    version: '20260722.5',
    registryVersion: registryContract.version,
    criticalRelease: CRITICAL_RELEASE,
    directoryVisibilityRevision: DIRECTORY_VISIBILITY_REVISION,
    owner: 'core/router-tenant-config-bootstrap.js',
    canonicalVisualOwner: 'core/client-insurer-visual-contract-v20260720.js',
    canonicalOperationalDirectoryOwner: 'core/client-insurer-operational-directory-owner-v20260722.js',
    latestOperationalDirectoryOwnerVersion: '20260829.1',
    canonicalEditOwner: 'core/client-insurer-edit-owner-v20260722.js',
    editModeAware: true,
    editModeStatus: 'EDIT_MODE_READY',
    failVisible: true,
    knowledgeSettledBeforeVisible: true,
    directoryFirstPaintGuard: true,
    eventDriven: true,
    domMutationGuard: true,
    directoryStructuralTrigger: true,
    scheduleStablePass: scheduleStablePass,
    expectedReady: expectedReady,
    writesStore: false,
    reimportsData: false,
    exposesSecrets: false
  };
  scheduleStablePass('bootstrap');
})();
